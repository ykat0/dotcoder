#ifndef __FASTA_H__
#define __FASTA_H__
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <ext/stdio_filebuf.h>
#define DEBUG 0

using namespace std;

class Fasta {
private:
  string filename;
  int dna;
  int gzip;
public:
  Fasta(string filename, int dna, int gzip);
  void getSeq(vector<string> &id, vector<string> &seq);
};
#endif
