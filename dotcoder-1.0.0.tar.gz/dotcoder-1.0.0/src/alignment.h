#ifndef __ALIGNMENT_H__
#define __ALIGNMENT_H__
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>
#define DEBUG 0

using namespace std;

class Alignment {
private:
  int match, mismatch, gapd, cutoff;
public:
  Alignment(int match, int mismatch, int gapd, int cutoff);
  int alignGlobally(vector<int> x, vector<int> y);
};

string int2str(int i);
void showAlignment(string xal, string yal);
#endif
